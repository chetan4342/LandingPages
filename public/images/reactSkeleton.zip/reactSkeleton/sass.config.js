const __dirname = "./";
module.exports = {
	// Options for node-sass
	sassOptions: {
		// Include paths for SCSS imports
		includePaths: [`${__dirname}/src`],
	},
};
