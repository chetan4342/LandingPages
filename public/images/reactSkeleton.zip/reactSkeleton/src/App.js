import { Provider } from "react-redux";
import "./App.css";
// import "antd/dist/antd.css";
import { styled } from "styled-components";
import { store } from "./redux/store";
import AppRouter from "./routes/AppRouter";
// import "./App.css";
import "./assets/css/form.scss";
import "./assets/css/loginForm.scss";
// import "./assets/css/previewcreation.scss";
import "./assets/css/soOnboarding.scss";
import "./assets/css/stepper.css";
import "./assets/css/style.css";
import "./assets/css/profile.scss";
import MainRouter from "./routes/MainRouter";
import Spinner from "./components/general/Spinner";

function App() {
	return (
		<Container className="App">
			<Provider store={store}>
				<Spinner>
					<MainRouter />
				</Spinner>
			</Provider>
		</Container>
	);
}

export default App;
const Container = styled.div``;
