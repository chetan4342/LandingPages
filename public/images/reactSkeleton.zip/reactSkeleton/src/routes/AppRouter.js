import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { styled } from "styled-components";
import ProfileScreen from "../components/profile/ProfileScreen";
import SideBar from "../components/sidebar";
import Header from "../components/general/header";

function AppRouter() {
	console.log("appRouter");
	return (
		<Container>
			<Header />
			<SideBar />
			<Routes>
				<Route path="/" element={<Navigate to="/dashboard" />} />
				<Route path="/profile" element={<ProfileScreen />} />
				<Route path="/dashboard" />
				<Route path="*" element={<Navigate to="/login" />} />
			</Routes>{" "}
		</Container>
	);
}

export default AppRouter;
const Container = styled.div`
	padding: 95px 20px 20px 110px;
`;
