import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Login from "../components/auth/Login";

const AuthRouter = () => {
	console.log("AUth");
	return (
		<>
			<Routes>
				<Route path="/" element={<Navigate to="/login" />} />
				<Route path="/login" element={<Login />} />
				<Route path="*" element={<Navigate to="/login" />} />
			</Routes>
		</>
	);
};

export default AuthRouter;
