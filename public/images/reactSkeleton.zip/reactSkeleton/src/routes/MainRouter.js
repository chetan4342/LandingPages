import React from "react";
import { Route, Routes } from "react-router-dom";
import { styled } from "styled-components";
import { IsAuthenticated } from "../utils/HelperFunction";
import AuthRouter from "./AuthRouter";
import AppRouter from "./AppRouter";

function MainRouter() {
	return (
		<Container>
			<Routes>
				<Route
					path="/*"
					element={IsAuthenticated() ? <AppRouter /> : <AuthRouter />}
				/>
			</Routes>{" "}
		</Container>
	);
}

export default MainRouter;
const Container = styled.div``;
