import MASTER_API from "./master_api";
export default async (options) => {
  try {
    return await MASTER_API(options);
  } catch (exception) {
    return exception;
  }
};
