export const Colors = {
    WHITE: '#FFFFFF',
  };