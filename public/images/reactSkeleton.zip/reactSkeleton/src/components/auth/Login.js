import React, { useState } from "react";
import { preventCopyPaste } from "../../utils/HelperFunction";
import { Input, Divider, notification } from "antd";
import smartphoneman from "../../assets/images/CreateIllustrator.png";
import background from "../../assets/images/background.png";
import logo from "../../assets/images/logo.png";
import OtpInput from "react-otp-input";
import { ArrowLeftOutlined } from "@ant-design/icons";

function Login() {
	const [stepvalue, setStepValue] = useState(0);
	const [userEmailId, setUserEmailId] = useState("");
	const [otp, setOTP] = useState("");

	const onSubmit = async () => {
		if (otp.length < 5) {
			notification.error({ message: "Please enter correct OTP" });
		} else {
			const data = {
				username: userEmailId,
				otp: otp,
			};
			// const response = await userAPI().emailOtpVerify(data);

			// if (response?.status === 400) {
			// 	notification.error({ message: response?.message });
			// } else {
			// 	notification.success({ message: response?.message });
			// 	sessionStorage.setItem("access_token", response?.access);
			// 	sessionStorage.setItem("refresh_token", response?.refresh);

			// 	// <Redirect to="/profile" />
			// 	history.push("/profile");
			// }
		}
	};

	const sendOTP = async () => {
		const data = {
			username: userEmailId,
		};
		// const response = await userAPI().sendOtpToEmail(data);
		// if (response.status === 200) {
		// 	notification.success({ message: "OTP sent to your Email ID" });
		// 	setStepValue(1);
		// } else {
		// 	notification.error({ message: "Please retry again" });
		// }
	};
	const resendOTP = async () => {
		const data = {
			email: userEmailId,
		};
		// const response = await userAPI().reSendOtpToEmail(data);
		// if (response.status === 200) {
		// 	notification.success({ message: "OTP sent to your Email ID" });
		// } else {
		// 	notification.error({ message: "Please retry again" });
		// }
	};
	const loginClick = () => {
		const re_email =
			/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

		if (userEmailId) {
			if (!re_email.test(userEmailId)) {
				notification.error({
					message: "Please enter correct Email ID",
				});
				return false;
			} else {
				// sendOTP();
				setStepValue(1);
			}
		} else {
			notification.error({ message: "Please enter Email ID" });
		}
	};

	const handleChange = (e) => {
		setOTP(e);
	};
	return (
		<div className="bgcoloroverview w-100">
			<div className="authForm formStyles">
				<div className="row align-items-center" id="wrapper">
					<img
						src={background}
						style={{
							position: "absolute",
							marginLeft: "24%",
							zIndex: "-1",
						}}
					/>
					<div
						className="col-md-12"
						style={{ background: "#54595F", height: "68px" }}
					>
						{" "}
						<img
							src={logo}
							style={{ padding: "5px", marginLeft: "10%" }}
						/>
					</div>
					<div className="col-md-6" id="firstDiv">
						<div className="authForm">
							<img
								src={smartphoneman}
								className=""
								style={{ marginTop: "6%" }}
							/>
						</div>
						<div>
							<p className="textParagraph">
								“Integreon’s expertise and willingness to
								innovate allows me to deliver increased
								efficiency to my key internal clients, our
								attorneys, so they can focus on higher-value
								work.”
							</p>
						</div>
					</div>
					<div className="col-md-5" id="secondDiv">
						<div className="registrationContent">
							{stepvalue === 0 ? (
								<>
									<h5 className="cardHeading">
										Hello, Welcome
									</h5>
									<br></br>
									<div className="row">
										<div className="col-sm-12 ">
											<div className="form-group input-group">
												<label className="has-float-label">
													<Input
														className="form-control"
														name="userEmailId"
														id="emailid"
														value={userEmailId}
														onInput={(e) =>
															setUserEmailId(
																e.target.value
															)
														}
														onChange={(e) =>
															setUserEmailId(
																e.target.value
															)
														}
														placeholder=" "
														onCopy={(e) =>
															preventCopyPaste(e)
														}
														onCut={(e) =>
															preventCopyPaste(e)
														}
													/>
													<span>Email ID</span>
												</label>
											</div>
										</div>
									</div>

									<div className="form-group textCenter authForm">
										{/* <button type="submit" className="btn loginButton" onClick={() => onSubmit()}> */}
										<button
											type="submit"
											className="btn loginButton"
											onClick={() => loginClick()}
										>
											Login
										</button>
									</div>
								</>
							) : (
								<div>
									<h5 className="OTPcardHeading">
										Enter OTP
									</h5>
									<p className="marginAuto textCenter otpVerifyMessage">
										A 5-Digit code has been sent to{" "}
										<span style={{ color: "#B42597" }}>
											{userEmailId}
										</span>
									</p>
									<div
										className="formStyles1 form-group d-flex content-center"
										style={{ marginTop: "20px" }}
									>
										<OtpInput
											value={otp}
											onInput={(e) => setOTP(e)}
											onChange={(e) => handleChange(e)}
											numInputs={5}
											inputStyle="inputWidth"
											separator={<span>-</span>}
											onCopy={(e) => preventCopyPaste(e)}
											onCut={(e) => preventCopyPaste(e)}
											renderInput={(props) => (
												<input {...props} />
											)}
										/>
									</div>
									<div className="form-group textCenter authForm">
										{/* <button type="submit" className="btn loginButton" onClick={() => onSubmit()}> */}
										<button
											type="submit"
											className="btn loginButton"
											onClick={() => onSubmit()}
										>
											Verify & Login
										</button>
									</div>
									<div>
										<button
											style={{
												border: "0px",
												background: "none",
												textDecoration: "underline",
												color: "#54585A",
											}}
											onClick={() => setStepValue(0)}
										>
											{" "}
											<ArrowLeftOutlined /> Go Back
										</button>
										<button
											style={{
												border: "0px",
												background: "none",
												float: "right",
												textDecoration: "underline",
												color: "#54585A",
											}}
											onClick={() => resendOTP()}
										>
											Resend OTP
										</button>
									</div>
								</div>
							)}
						</div>
					</div>
					<div
						className="col-md-12"
						style={{
							background: "#54595F",
							height: "45px",
							padding: "10px 0px 10px 10%",
							color: "#ffffff",
							fontSize: "16px",
							fontWeight: "500",
							position: "fixed",
							bottom: 0,
							left: 0,
						}}
					>
						{" "}
						©Integreon, Inc. or all of its affiliates. All rights
						reserved.
					</div>
				</div>
			</div>
			{/* <div>Footer</div> */}
		</div>
	);
}

export default Login;
