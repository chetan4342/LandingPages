import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { Input, Select, Upload, Switch, Button, TimePicker, Tooltip, notification } from "antd";
import { useFormik } from "formik";
import { UploadOutlined, PlusOutlined, LoadingOutlined } from "@ant-design/icons";
import { Profile } from "../../constants/strings";
import { Colors } from "../../constants/colors";
import profile from "../../assets/images/profile.png";
import profileApi from "../../api/profileApi";

function ProfileScreen() {
	const [loading, setLoading] = useState(false);
	const [imageValidation,setImageValidation]=useState(true);
	const [imageUrl, setImageUrl] = useState("");

	useEffect(() => {
		const res = profileApi().getTeams();
	}, []);

	const getBase64 = (img, callback) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => callback(reader.result));
    reader.readAsDataURL(img);
  };
  const beforeUpload = (file) => {
    const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
    if (!isJpgOrPng) {
      setImageValidation(false);
      notification.error({ message: "You can only upload JPG/PNG file!" });
      // setImageFile(file);
    }
    else{
      setImageValidation(true);
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      setImageValidation(false);
      notification.error({ message: "Image must smaller than 2MB!" });
    }
    
    return isJpgOrPng && isLt2M;
  };

	const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    // if (info.file.status === "done") {
      // Get this url from response in real world.
      if(imageValidation)
      {
        
        getBase64(info.file.originFileObj, (url) => {
          setLoading(false);
          setImageUrl(url);
        });
      }
    // }
  };

	const uploadButton = <div>{loading ? <LoadingOutlined /> : <img src={profile} />}</div>;

	return (
		<OuterContainer>
			<span>{Profile.PROFILE_SCREEN}</span>
			<MainContainer>
			<span>{Profile.PROFILE_INFO}</span>
			<InputCover style={{ alignItems: 'center' }}>
				<InputOuter>
          <label className="has-float-label label" style={{ width: "100%", fontsize: "16px !important" }}>
            <Input
              style={{ width: "100%", fontSize: "14px", paddingRight: 30 }}
              className="form-control"
              type="text"
              maxLength="45"
              name="name"
              id="name"
              // value={formik.values.name}
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              placeholder=" "
            />

            <span>{Profile.FIRSTNAME}</span>
          </label>
          {/* s */}
        </InputOuter>
				<InputOuter>
          <label className="has-float-label label" style={{ width: "100%", fontsize: "16px !important" }}>
            <Input
              style={{ width: "100%", fontSize: "14px", paddingRight: 30 }}
              className="form-control"
              type="text"
              maxLength="45"
              name="name"
              id="name"
              // value={formik.values.name}
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              placeholder=" "
            />

            <span>{Profile.LASTNAME}</span>
          </label>
          {/* s */}
        </InputOuter>
				<div className="col-md-3 profileUpload">
              <div>
                {/* <img src={profile} />
                 */}
                <Upload
                  name="avatar"
                  listType="picture-circle"
                  className="avatar-uploader"
                  showUploadList={false}
                  // action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  // beforeUpload={beforeUpload}
                  // onChange={handleChange}
                >
                  {imageUrl ? <img src={imageUrl} alt="avatar" style={{ width: "100%" }} /> : uploadButton}
                </Upload>
              </div>
              {/* <div>
                <span className="profileSpan">Only JPEG, PNG files with max size of 1 MB.</span>
                <Upload showUploadList={false} beforeUpload={beforeUpload}
                  onChange={handleChange}>
                  <Button icon={<UploadOutlined />} onChange={handleChange}>
                    Click to Upload
                  </Button>
                </Upload>
              </div> */}
            </div>
				<InputOuter>
          <label className="has-float-label label" style={{ width: "100%", fontsize: "16px !important" }}>
            <Input
              style={{ width: "100%", fontSize: "14px", paddingRight: 30 }}
              className="form-control"
              type="text"
              maxLength="45"
              name="name"
              id="name"
              // value={formik.values.name}
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              placeholder=" "
            />

            <span>{Profile.ROLE}</span>
          </label>
          {/* s */}
        </InputOuter>	
				<InputOuter>
          <label className="has-float-label label" style={{ width: "100%", fontsize: "16px !important" }}>
            <Input
              style={{ width: "100%", fontSize: "14px", paddingRight: 30 }}
              className="form-control"
              type="text"
              maxLength="45"
              name="name"
              id="name"
              // value={formik.values.name}
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              placeholder=" "
            />

            <span>{Profile.EMAIL_ADDRESS}</span>
          </label>
          {/* s */}
        </InputOuter>	
				<InputOuter>
          <label className="has-float-label">
            <Select
              defaultValue="Select Country"
              className="form-control"
              name="country"
              style={{ width: "100%", fontSize: "14px" }}
              // value={formik.values.country}
              // // onChange={formik.handleChange}
              // onChange={(value) => {
              //   formik.setFieldValue("country", value);
              //   setCountryCode(country.find((country) => country[1] === value)[0]);
              // }}
              // onBlur={formik.handleBlur}
            >
              {/* {country?.map((country) => (
                <Option key={country[0]} value={country[1]}>
                  {country[1]}
                </Option>
              ))} */}
            </Select>
            <span>{Profile.WORK_LOCATION}</span>
          </label>{" "}
          {/* {formik.touched.country && formik.errors.country ? <ErrorText>{formik.errors.country}</ErrorText> : null} */}
        </InputOuter>
				</InputCover>
				<InputCover>
				<InputOuter>
          <label className="has-float-label label" style={{ width: "100%", fontsize: "16px !important" }}>
            <Input
              style={{ width: "100%", fontSize: "14px", paddingRight: 30 }}
              className="form-control"
              type="text"
              maxLength="45"
              name="name"
              id="name"
              // value={formik.values.name}
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              placeholder=" "
            />

            <span>{Profile.ENTER_MOBILE_NUMBER}</span>
          </label>
          {/* s */}
        </InputOuter>
				<div style={{ alignItems: "center" }}>
					<InputOuter>
						<label className="has-float-label">
							<Select
								defaultValue="Select Country"
								className="form-control"
								name="country"
								style={{ width: "100%", fontSize: "14px" }}
								// value={formik.values.country}
								// // onChange={formik.handleChange}
								// onChange={(value) => {
								//   formik.setFieldValue("country", value);
								//   setCountryCode(country.find((country) => country[1] === value)[0]);
								// }}
								// onBlur={formik.handleBlur}
							>
								{/* {country?.map((country) => (
									<Option key={country[0]} value={country[1]}>
										{country[1]}
									</Option>
								))} */}
							</Select>
							<span>{Profile.TIMEZONE}</span>
						</label>{" "}
						{/* {formik.touched.country && formik.errors.country ? <ErrorText>{formik.errors.country}</ErrorText> : null} */}
					</InputOuter>
					<div>
						<span>{Profile.ADJUST_DAYLIGHT}</span><br />
						<Switch size="small" defaultChecked />
					</div>
				</div>
				<div>
					<span style={{ padding: '10px' }}>{Profile.WORK_HOURS}</span>
					<div style={{ display: 'flex', marginTop: '20px' }}>
						<InputOuter style={{ marginRight: '20px'}}>
							<label className="has-float-label">
								<Select
									defaultValue="Select Country"
									className="form-control"
									name="country"
									style={{ width: "100%", fontSize: "14px" }}
									// value={formik.values.country}
									// // onChange={formik.handleChange}
									// onChange={(value) => {
									//   formik.setFieldValue("country", value);
									//   setCountryCode(country.find((country) => country[1] === value)[0]);
									// }}
									// onBlur={formik.handleBlur}
								>
									{/* {country?.map((country) => (
										<Option key={country[0]} value={country[1]}>
											{country[1]}
										</Option>
									))} */}
								</Select>
								<span>{Profile.START_TIME}</span>
							</label>{" "}
							{/* {formik.touched.country && formik.errors.country ? <ErrorText>{formik.errors.country}</ErrorText> : null} */}
						</InputOuter>
						<InputOuter>
							<label className="has-float-label">
								<Select
									defaultValue="Select Country"
									className="form-control"
									name="country"
									style={{ width: "100%", fontSize: "14px" }}
									// value={formik.values.country}
									// // onChange={formik.handleChange}
									// onChange={(value) => {
									//   formik.setFieldValue("country", value);
									//   setCountryCode(country.find((country) => country[1] === value)[0]);
									// }}
									// onBlur={formik.handleBlur}
								>
									{/* {country?.map((country) => (
										<Option key={country[0]} value={country[1]}>
											{country[1]}
										</Option>
									))} */}
								</Select>
								<span>{Profile.END_TIME}</span>
							</label>{" "}
							{/* {formik.touched.country && formik.errors.country ? <ErrorText>{formik.errors.country}</ErrorText> : null} */}
						</InputOuter>
					</div>
				</div>
				</InputCover>
				<UpdateButton>{Profile.UPDATE}</UpdateButton>
				</MainContainer>
		</OuterContainer>
	);
}

export default ProfileScreen;

const OuterContainer = styled.div`
  padding: 20px;
	background-color: #f5f5f5;
	height: 100vh;
`;
const MainContainer = styled.div`
  padding: 12px 20px;
  background: #ffffff;
	border-radius: 5px;
`;
const InputCover = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 40px;
  padding: 20px;
  .form-control:placeholder-shown:not(:focus) + * {
    font-size: 15px !important;
    top: 0.5em !important;
  }
  .ant-select-single:not(.ant-select-customize-input) .ant-select-selector {
    padding: 0;
    padding-right: 0px;
  }
  .has-float-label > span {
    background-color: #fff;
    padding: 3px 5px;
    top: -1em;
  }
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    border: none !important;
    outline: none;
    box-shadow: none !important;
    transform: translateY(-5px);
    margin-bottom: -5px;
  }
  .react-tel-input .flag-dropdown {
    background-color: #fff;
  }
  .react-tel-input .form-control {
    width: 100%;
    padding-right: 0;
  }
`;
const InputOuter = styled.div`
  position: relative;
`;

const UpdateButton = styled.button`
  cursor: pointer;
  width: 170px;
  height: 40px;
  background-color: #4dbcba;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #fff;
  font-weight: 600;
  margin-left: auto;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 20px;
  border: none;
  outline: none;

  :hover {
    opacity: 0.8;
  }
`;
const Error = styled.span`
  display: block;
  width: 17px;
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-67%);
  img {
    width: 100%;
    display: block;
  }
`;