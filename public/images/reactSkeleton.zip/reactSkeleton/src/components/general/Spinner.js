import React from "react";
import { Spin } from "antd";
import { useSelector } from "react-redux";

const Spinner = ({ children }) => {
	const showLoader = useSelector((state) => state.ui_state.showLoader);
	return (
		<Spin
			tip="Loading..."
			spinning={showLoader}
			size="large"
			style={{ height: "100vh" }}
		>
			{children}
		</Spin>
	);
};

export default Spinner;
