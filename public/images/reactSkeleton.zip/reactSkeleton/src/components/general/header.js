// import { faAngleDown } from "@fortawesome/free-solid-svg-icons";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { isNull } from "lodash";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ReactRoundedImage from "react-rounded-image";
import { Redirect } from "react-router";
import { Link, useHistory, useLocation } from "react-router-dom";
import user from "../../assets/images/topProfile.png";
import notificationIcon from "../../assets/images/notificationIcon.png";
import logo from "../../assets/images/logo.png";
// import appRoutes from "../../constants/app-routes";
// import { sidebarActions } from "../../redux/ui/uiActions";
// import apiRequest from "../../utils/api-utils/api-request";
// import { BellFilled } from "@ant-design/icons";

// const sidebarRoutes = [
// 	`/dashboard`,
// 	`/profile`,
// 	`/team/teamsManagement-Invite`,
// 	`/team/teamsManagement-Create`,
// 	`/team/view-team`,
// 	// `${appRoutes.ORGANISATION}`,
// 	`/SLAManagement`,
// 	`/sla-management/create-sla-categories`,
// 	"/sla-management/map-sla-to-team",
// 	"/scope-management/create-scope",
// 	"/team/create-shift", // `${appRoutes.ORGANISATION}`,
// 	"/team/create-shift",
// 	"/master-data/mapping",
// 	"/scope-management/entity",
// 	"/scope-management/category",
// 	"/rules-configuration/",
// 	"/rules-configuration/assign-rule",
// 	`${appRoutes.ORGANISATION}`,
// 	`${appRoutes.PROGRAM_OVERVIEW}`,
// 	`${appRoutes.BENEFICIARY}`,
// 	`${appRoutes.BENEFICIARY_LIST}`,
// 	`${appRoutes.ADD_MEMBER}`,
// 	`${appRoutes.CREATE_SLA_CATEGORIE}`,
// 	`/ProgramOverviewMain`,
// 	`/invite-user`,
// ];

const Header = () => {
	const userDetailsValue = useSelector((state) => state.user.userDetails);
	// console.log("userDetails1234567",userDetailsValue?.inviteStatus);
	const [uData, setUData] = useState({
		responseData: "",
		firstName: "User",
		redirect: true,
	});
	const [userType, setUserType] = useState(
		sessionStorage.getItem("userRole")
	);
	const [userDetails, setUserDetails] = useState(
		sessionStorage.getItem("detailsUpdated")
	);
	// const showSidebar = useSelector((state) => state.ui.showSidebar);

	const dispatch = useDispatch();
	// const history = useHistory();
	const location = useLocation();

	console.log(location.pathname);

	// useEffect(() => {
	// 	if (sidebarRoutes.includes(location.pathname)) {
	// 		dispatch(sidebarActions.showSidebar());
	// 	} else {
	// 		dispatch(sidebarActions.hideSidebar());
	// 	}
	// }, [location.pathname]);

	const token = sessionStorage.getItem("access_token");

	const doLogout = async () => {
		const refreshToken = sessionStorage.getItem("refresh_token");
		// return apiRequest({
		// 	url: "/api/users/logout",
		// 	method: "POST",
		// 	data: {
		// 		refresh_token: refreshToken,
		// 	},
		// });
	};

	const logout = async () => {
		await doLogout();
		sessionStorage.removeItem("access_token");
		sessionStorage.removeItem("refresh_token");
		sessionStorage.removeItem("headerVisibility");
		sessionStorage.clear();
		// dispatch(sidebarActions.hideSidebar());
		// history.push("/login");
	};

	return (
		<>
			{/* {console.log('userType userType userType', userType,token)} */}
			{!token && (
				<header id="header" className="fixed-top">
					<div
						className="container d-flex align-items-center h-100"
						style={{
							maxWidth: "100vw",
							padding: "0 50px",
							display: "flex !important ",
							justifyContent: "space-between",
							alignItems: "center",
						}}
					>
						<img src={logo} />
						<a className=" mr-auto " />
						<nav className="nav-menu d-none d-lg-block">
							<ul
								style={{
									width: "100%",
								}}
							>
								<li>
									<img src={notificationIcon} />
								</li>
								<li className="drop-down">
									<div style={{ display: "flex" }}>
										<ReactRoundedImage
											image={user}
											roundedSize="0"
											imageWidth="30"
											imageHeight="30"
										/>
										{/* <FontAwesomeIcon
											icon={faAngleDown}
											style={{
												margin: "auto 6px",
												color: "#4DC2BF",
											}}
										/> */}
									</div>
									<ul>
										<li>
											<Link to="/profile">Profile</Link>
										</li>
										<li>
											<a onClick={() => logout()}>
												Logout
											</a>
										</li>

										{/* <li>
                      <a href="#">Drop Down 2</a>
                    </li>
                    <li>
                      <a href="#">Drop Down 3</a>
                    </li> */}
									</ul>
								</li>
							</ul>
						</nav>
					</div>
				</header>
			)}
		</>
	);
};

export default Header;
