import { Layout, Menu, Button } from "antd";
import { Link, useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
// import { PROJECT, ROLES } from "../../constants/strings";

import { ReactComponent as DashboardIcon } from "../../assets/images/sidebarIcons/dashboard.svg";
import { ReactComponent as CreateTeam } from "../../assets/images/sidebarIcons/createTeam.svg";
import { ReactComponent as AddMember } from "../../assets/images/sidebarIcons/addMember.svg";
import { ReactComponent as ViewTeam } from "../../assets/images/sidebarIcons/viewTeam.svg";
import { ReactComponent as Shift } from "../../assets/images/sidebarIcons/shift.svg";
import { ReactComponent as Teams } from "../../assets/images/sidebarIcons/teams.svg";
import { ReactComponent as MasterData } from "../../assets/images/sidebarIcons/masterData.svg";

import { ReactComponent as Sla } from "../../assets/images/sidebarIcons/sla.svg";
import { ReactComponent as Scope } from "../../assets/images/sidebarIcons/scope.svg";
import { ReactComponent as Rule } from "../../assets/images/sidebarIcons/rule.svg";
import { ReactComponent as Map } from "../../assets/images/sidebarIcons/map.svg";
import { ReactComponent as Define } from "../../assets/images/sidebarIcons/define.svg";
import { ReactComponent as CreateCategory } from "../../assets/images/sidebarIcons/createCategory.svg";
import { ReactComponent as CreateEntity } from "../../assets/images/sidebarIcons/createEntity.svg";
import { ReactComponent as CreateScope } from "../../assets/images/sidebarIcons/createScope.svg";
import { ReactComponent as LeftArrow } from "../../assets/images/sidebarIcons/leftArrow.svg";
import { ReactComponent as RightArrow } from "../../assets/images/sidebarIcons/rightArrow.svg";
import { ReactComponent as OpenBook } from "../../assets/images/sidebarIcons/book-open.svg";

const { Sider } = Layout;

// const getMenuItems = (
// 	userDetails,
// 	orgApprovalStatus,
// 	signedAgreement,
// 	isAdmin
// ) => {
// 	// const userDetails = useSelector((state) => state.user.userDetails);
// 	const menuItems = [
// 		{
// 			id: 1,
// 			option: "Knowledge Partners",
// 			link: "/knowledge-partners",
// 			isActive: true,
// 			roles: [],
// 			icon: <DesktopOutlined />,
// 		},
// 		{
// 			id: 2,
// 			option: "Beneficiary",
// 			link: appRoutes.BENEFICIARIES,
// 			isActive: true,
// 			roles: [],
// 			icon: <ContainerOutlined />,
// 		},
// 		{
// 			id: 3,
// 			option: "Job Portal",
// 			link: "/job-portal",
// 			isActive: true,
// 			roles: [],
// 			icon: <MailOutlined />,
// 		},

// 		{
// 			id: 4,
// 			option: "Settings",
// 			link: "/settings",
// 			isActive: true,
// 			roles: [],
// 			icon: <ContainerOutlined />,
// 		},

// 		{
// 			id: 5,
// 			option: "My Networks",
// 			link: "/dashboard",
// 			isActive: false,
// 			roles: [],
// 			icon: <DesktopOutlined />,
// 		},
// 	];

// 	fetchUserData();
// 	return menuItems;
// };

const SideBar = () => {
	const userDetails = useSelector((state) => state.user.userDetails);
	const role = sessionStorage.getItem("role");
	const isAdmin = false;
	// 	sessionStorage.getItem("role") === ROLES.ADMIN ? true : false;
	// const [userType, setUserType] = useState(
	// 	sessionStorage.getItem("userRole")
	// );
	const [userDetails2, setUserDetails2] = useState(
		sessionStorage.getItem("detailsUpdated")
	);
	// const history = useHistory();
	const [path, setPath] = useState();

	// useEffect(async () => {
	// 	const response = await userAPI().profileData();
	// 	if (response) {
	// 		sessionStorage.setItem("role", response?.data?.roles?.[0]?.name);
	// 	}

	// 	setPath(window.location.href);
	// });

	const [collapsed, setCollapsed] = useState(true);
	const toggleCollapsed = () => {
		setCollapsed(!collapsed);
		console.log("collapsed", collapsed);
	};

	return (
		<div
			style={{
				width: 256,
				position: "fixed",
				left: "0",
				top: "75px",
			}}
		>
			{/* <div className="logo"> */}

			<Menu
				mode="inline"
				defaultSelectedKeys={["0"]}
				defaultOpenKeys={["sub1"]}
				style={{
					height: "100vh",
					borderRight: 0,
					position: "relative",
					paddingTop: "30px",
				}}
				theme="dark"
				inlineCollapsed={collapsed}
				// items={items}
			>
				<Menu.Item className="mainItemStyle" icon={<DashboardIcon />}>
					<Link to="/dashboard">
						{/*<DashboardIcon style={{ marginRight: "10px" }} />*/}
						<span>
							<b>Dashboard</b>
						</span>
					</Link>
				</Menu.Item>

				<Button
					type="primary"
					onClick={toggleCollapsed}
					style={{
						marginTop: 25,
						background: "#1b1e24",
						border: "0px",
						float: "right",
						position: "absolute",
						bottom: "calc(100vh - (100vh - 100px))",
						right: 0,
					}}
				>
					{collapsed ? <RightArrow /> : <LeftArrow />}
				</Button>
			</Menu>
		</div>
	);
};

export default SideBar;
