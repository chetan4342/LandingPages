import { createSlice } from "@reduxjs/toolkit";

const INITAIL_STATE = {
	userData: sessionStorage.getItem("userData")
		? JSON.parse(sessionStorage.getItem("userData"))
		: {
				name: "",
				phone: "",
				country: "",
				email: "",
		  },

	userProfile: {},
};

const userSlice = createSlice({
	name: "user",
	initialState: INITAIL_STATE,
	reducers: {
		updateUserData: (state, action) => {
			state.userData = { ...state.userData, ...action.payload };
			sessionStorage.setItem("userData", JSON.stringify(state.userData));
		},
		updateUserProfile: (state, action) => {
			state.userProfile = { ...state.userProfile, ...action.payload };
		},
	},
});

export const { updateUserData, updateUserProfile } = userSlice.actions;
export default userSlice.reducer;
