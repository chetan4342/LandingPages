import apiRequest from "../utils/api-utils/api-request";

function profileApi() {
	return {
		getTeams: async (searchParam) => {
			return apiRequest({
				url: `/api/team/team/?limit=10000&order=id&search=${searchParam}`,
				method: "GET",
			});
		},
	};
}

export default profileApi;
//
