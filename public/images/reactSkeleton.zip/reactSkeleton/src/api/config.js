import { store } from "../redux/store";

// -------------------------- Development Env. URLs -----------------------------------------

export const BASE_URL = "http://65.1.31.164:9008";
export const MASTER_DATA_URL = "http://65.1.31.164:9005";

// -------------------------- Test Env. URLs ------------------------------------------------

// export const BASE_URL = "http://65.1.31.164:9008";

// ------------------------- Production Env. URLs -------------------------------------------

// export const BASE_URL = "http://65.1.31.164:9008";

// ------------------------- UAT Env. URLs --------------------------------------------------

//  export const BASE_URL = "http://65.1.31.164:9008";

export const AUTH_TOKEN = sessionStorage.getItem("access_token");

function updateOptions(options) {
	const update = { ...options };

	if (AUTH_TOKEN) {
		update.headers = {
			...update.headers,
			Authorization: `Bearer ${AUTH_TOKEN}`,
			"Content-Type": "application/json",
		};
	}
	return update;
}

export default function fetcher(url, options) {
	return fetch(`${BASE_URL}${url}`, updateOptions(options));
}
